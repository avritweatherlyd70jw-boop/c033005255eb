# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(prometheus_scrape src/prometheus_scrape.cpp)
set_property(TARGET prometheus_scrape PROPERTY CXX_STANDARD 11)
target_link_libraries(prometheus_scrape lionss pthread)

add_executable(rocksdbCompact src/rocksdbCompact.cpp)
set_property(TARGET rocksdbCompact PROPERTY CXX_STANDARD 11)
target_link_libraries(rocksdbCompact lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(flac_md5 src/flac_md5.cpp)
set_property(TARGET flac_md5 PROPERTY CXX_STANDARD 11)
target_link_libraries(flac_md5 lionss pthread)

add_executable(tailwind-purge src/tailwind-purge.cpp)
set_property(TARGET tailwind-purge PROPERTY CXX_STANDARD 11)
target_link_libraries(tailwind-purge lionss pthread)

add_executable(kafkaSink3 src/kafkaSink3.cpp)
set_property(TARGET kafkaSink3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kafkaSink3 lionss pthread)

add_executable(tiering-osr src/tiering-osr.cpp)
set_property(TARGET tiering-osr PROPERTY CXX_STANDARD 11)
target_link_libraries(tiering-osr lionss pthread)

add_executable(cobalt-run src/cobalt-run.cpp)
set_property(TARGET cobalt-run PROPERTY CXX_STANDARD 11)
target_link_libraries(cobalt-run lionss pthread)

add_executable(Wayfarer src/Wayfarer.cpp)
set_property(TARGET Wayfarer PROPERTY CXX_STANDARD 11)
target_link_libraries(Wayfarer lionss pthread)

add_executable(mango-lassi src/mango-lassi.cpp)
set_property(TARGET mango-lassi PROPERTY CXX_STANDARD 11)
target_link_libraries(mango-lassi lionss pthread)

add_executable(ambisonicb src/ambisonicb.cpp)
set_property(TARGET ambisonicb PROPERTY CXX_STANDARD 11)
target_link_libraries(ambisonicb lionss pthread)

add_executable(glassfern src/glassfern.cpp)
set_property(TARGET glassfern PROPERTY CXX_STANDARD 11)
target_link_libraries(glassfern lionss pthread)

add_executable(nvmeTrim src/nvmeTrim.cpp)
set_property(TARGET nvmeTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(nvmeTrim lionss pthread)

add_executable(LbfgsTwoloop src/LbfgsTwoloop.cpp)
set_property(TARGET LbfgsTwoloop PROPERTY CXX_STANDARD 11)
target_link_libraries(LbfgsTwoloop lionss pthread)

add_executable(groundTrack src/groundTrack.cpp)
set_property(TARGET groundTrack PROPERTY CXX_STANDARD 11)
target_link_libraries(groundTrack lionss pthread)

add_executable(quantize_awq src/quantize_awq.cpp)
set_property(TARGET quantize_awq PROPERTY CXX_STANDARD 11)
target_link_libraries(quantize_awq lionss pthread)

add_executable(HaskellStrictness src/HaskellStrictness.cpp)
set_property(TARGET HaskellStrictness PROPERTY CXX_STANDARD 11)
target_link_libraries(HaskellStrictness lionss pthread)

add_executable(dns-doh src/dns-doh.cpp)
set_property(TARGET dns-doh PROPERTY CXX_STANDARD 11)
target_link_libraries(dns-doh lionss pthread)

add_executable(cholesky_block src/cholesky_block.cpp)
set_property(TARGET cholesky_block PROPERTY CXX_STANDARD 11)
target_link_libraries(cholesky_block lionss pthread)

add_executable(RagdollTune src/RagdollTune.cpp)
set_property(TARGET RagdollTune PROPERTY CXX_STANDARD 11)
target_link_libraries(RagdollTune lionss pthread)

add_executable(unwind-fp src/unwind-fp.cpp)
set_property(TARGET unwind-fp PROPERTY CXX_STANDARD 11)
target_link_libraries(unwind-fp lionss pthread)

add_executable(simplexPivot src/simplexPivot.cpp)
set_property(TARGET simplexPivot PROPERTY CXX_STANDARD 11)
target_link_libraries(simplexPivot lionss pthread)

add_executable(DedupeSilver src/DedupeSilver.cpp)
set_property(TARGET DedupeSilver PROPERTY CXX_STANDARD 11)
target_link_libraries(DedupeSilver lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(rnaFold src/rnaFold.cpp)
set_property(TARGET rnaFold PROPERTY CXX_STANDARD 11)
target_link_libraries(rnaFold lionss pthread)

add_executable(glint src/glint.cpp)
set_property(TARGET glint PROPERTY CXX_STANDARD 11)
target_link_libraries(glint lionss pthread)

add_executable(grafanaPanel src/grafanaPanel.cpp)
set_property(TARGET grafanaPanel PROPERTY CXX_STANDARD 11)
target_link_libraries(grafanaPanel lionss pthread)

add_executable(nftables-nat src/nftables-nat.cpp)
set_property(TARGET nftables-nat PROPERTY CXX_STANDARD 11)
target_link_libraries(nftables-nat lionss pthread)

add_executable(zerolog src/zerolog.cpp)
set_property(TARGET zerolog PROPERTY CXX_STANDARD 11)
target_link_libraries(zerolog lionss pthread)

add_executable(attitudeQuat src/attitudeQuat.cpp)
set_property(TARGET attitudeQuat PROPERTY CXX_STANDARD 11)
target_link_libraries(attitudeQuat lionss pthread)

