// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("AWQ quantize weights\n", stdout);
  return lionss_run_workload("quantize_awq");
}
