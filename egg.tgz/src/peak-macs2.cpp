// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Call enrichment peaks"); }
int main(){
  announce();
  return lionss_run_workload("peak-macs2");
}
